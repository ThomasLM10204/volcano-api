-- Example content of dump.sql
DROP DATABASE IF EXISTS volcano_db;
CREATE DATABASE volcano_db;
USE volcano_db;

-- User creation
CREATE USER 'youruser'@'localhost' IDENTIFIED BY 'yourpassword';
GRANT ALL PRIVILEGES ON volcano_db.* TO 'youruser'@'localhost';

-- Table and data creation
CREATE TABLE volcanoes (...);
INSERT INTO volcanoes (...) VALUES (...);
-- Include all necessary tables and data

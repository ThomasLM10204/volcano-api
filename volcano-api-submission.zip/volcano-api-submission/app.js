const express = require('express');
const dotenv = require('dotenv');
const swaggerUI = require('swagger-ui-express');
const swaggerDocument = require('./swagger.json');
const https = require('https');

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());
app.use('/api-docs', swaggerUI.serve, swaggerUI.setup(swaggerDocument));

app.use('/auth', require('./routes/authRoutes'));
app.use('/profile', require('./routes/profileRoutes'));
app.use('/volcanoes', require('./routes/volcanoRoutes'));

app.get('/me', (req, res) => {
  res.json({
    name: "Le Minh Hoang",
    student_number: "n11143410"
  });
});

https.createServer(options, app).listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});

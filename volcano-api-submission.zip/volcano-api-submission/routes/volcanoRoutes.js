const express = require('express');
const { getCountries, getVolcanoes, getVolcanoById } = require('../controllers/volcanoController');
const router = express.Router();

router.get('/countries', getCountries);
router.get('/volcanoes', getVolcanoes);
router.get('/volcano/:id', getVolcanoById);

module.exports = router;

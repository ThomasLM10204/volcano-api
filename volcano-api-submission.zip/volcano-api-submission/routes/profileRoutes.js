const express = require('express');
const { getProfile, updateProfile } = require('../controllers/profileController');
const router = express.Router();
const authenticateToken = require('../middleware/authMiddleware');

router.get('/user/:email/profile', authenticateToken, getProfile);
router.put('/user/:email/profile', authenticateToken, updateProfile);

module.exports = router;

const db = require('../utils/db');

const getProfile = async (req, res) => {
  const { email } = req.params;
  const user = await db('users').where({ email }).first();
  if (!user) return res.sendStatus(404);
  res.json(user);
};

const updateProfile = async (req, res) => {
  const { email } = req.params;
  const updates = req.body;
  await db('users').where({ email }).update(updates);
  res.sendStatus(204);
};

module.exports = { getProfile, updateProfile };

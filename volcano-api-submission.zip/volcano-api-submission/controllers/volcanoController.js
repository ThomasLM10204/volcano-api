const db = require('../utils/db');

const getCountries = async (req, res) => {
  const countries = await db('volcanoes').distinct('country');
  res.json(countries);
};

const getVolcanoes = async (req, res) => {
  const { country } = req.query;
  const volcanoes = await db('volcanoes').where({ country });
  res.json(volcanoes);
};

const getVolcanoById = async (req, res) => {
  const { id } = req.params;
  const volcano = await db('volcanoes').where({ id }).first();
  if (!volcano) return res.sendStatus(404);
  res.json(volcano);
};

module.exports = { getCountries, getVolcanoes, getVolcanoById };

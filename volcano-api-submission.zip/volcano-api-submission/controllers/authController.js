const db = require('../utils/db');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const register = async (req, res) => {
  const { email, password } = req.body;
  const hashedPassword = await bcrypt.hash(password, 10);
  await db('users').insert({ email, password: hashedPassword });
  res.sendStatus(201);
};

const login = async (req, res) => {
  const { email, password } = req.body;
  const user = await db('users').where({ email }).first();
  if (!user) return res.sendStatus(404);
  
  const isValidPassword = await bcrypt.compare(password, user.password);
  if (!isValidPassword) return res.sendStatus(401);
  
  const token = jwt.sign({ email: user.email }, process.env.JWT_SECRET, { expiresIn: '1h' });
  res.json({ token });
};

module.exports = { register, login };
